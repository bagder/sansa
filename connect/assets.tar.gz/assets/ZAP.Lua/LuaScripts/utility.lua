-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Some useful utility methods and functions. Names are in CamelCase to distinguish
    them from the built-in Lua functions.
--]]

--
-- String enhancements
--

function string:UrlEncode()
    str = self:gsub( "\n", "\r\n" )
    str = str:gsub( "([^%w ])", function(c) return string.format("%%%02X", string.byte(c)) end )
    str = str:gsub( " ", "+" )
    return str	
end

function string:UrlDecode()
  str = self:gsub( "+", " " )
  str = str:gsub( "%%(%x%x)", function(h) return string.char(tonumber(h,16)) end )
  str = str:gsub( "\r\n", "\n" )
  return str
end

function string:StartsWith( other )
    if other ~= nil and type(other) == "string" then
        return self:sub(1,#other)==other
    end
    return false
end

function string:Trim()
  -- adapted from PiL2 20.4
  return (self:gsub("^%s*(.-)%s*$", "%1"))
end

function string:CaselessCompareTo( other )
    if other ~= nil and type(other) == "string" then
        return self:lower() == other:lower()
    end
    return false
end

--
-- URL encode a table of K=V pairs
--
function UrlEncode( t )
    local b = {}
    for k,v in pairs(t) do
        b[#b + 1] = ( k:UrlEncode() .. "=" ..  tostring(v):UrlEncode() )
    end
    return table.concat(b,"&")
end

-- parse a query string into k == v pairs, and return as a table
function ParseQuery( q )
    t = {}
    for pair in q:gmatch("[^&]+") do
        local key, value = pair:match("([^=]*)=(.*)")
        if key then
            if not value then
                value = ''
            end
            t[key:UrlDecode()] = value:UrlDecode()
        end
    end
    return t
end
