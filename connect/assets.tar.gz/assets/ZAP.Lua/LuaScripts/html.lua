-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer
-- (adapted from sample code found through lua-users.org)

--[[
    an iterator over all of the tags in an HTML document, which may not be well formed
    each tag is returned as a table. t[0] is the tag itself. Attributes are t[k]=v
    Tag and attribute names are always made lower case.
--]]

module(..., package.seeall)

function tags( content )
    local cursor, length = 1, #content
    
    return function()
        if cursor > length then
            -- EOF
            return nil
        end
        
        local htmltag = {}
        repeat
            -- get to open tag delimiter
            local first, last = content:find( "<", cursor, true )
            if first == nil or last == length then
                cursor = length + 1
                return nil
            end
            
            -- skip comments
            while content:sub( first, first + 3 ) == "<!--" do
                first, last = content:find( "-->", first + 4, true )
                if first == nil or last == length then
                    cursor = length + 1
                    return nil
                end
                first, last = content:find( "<", last + 1, true )
                if first == nil or last == length then
                    cursor = length + 1
                    return nil
                end
            end
            
            -- find tag
            first, cursor = content:find( "%S", last + 1 )
            if first == nil then
                cursor = length + 1
                return nil
            end
            
            first, last = content:find( "[!/]?%a%w*", cursor )
            if first == cursor then
                -- valid tag
                htmltag[0] = content:sub( first, last ):lower()
                
                if htmltag[0] == "!doctype" then
                    
                    -- doctype tag
                    first = content:find( "%S", last + 1 )
                    if first == nil then
                        cursor = length + 1
                        return htmltag
                    end
                    
                    -- parse attributes
                    last = content:find( "[>\"']", last ) or length + 1
                    local token = content:sub( last, last )
                    while token == "'" or token == '"' do
                        last = content:find( token, last + 1, true )
                        if last == nil then
                            last = length + 1
                            break
                        end
                        last  = content:find( "[>\"']", last + 1 ) or length + 1
                        token = content:sub( last, last )
                    end
                    cursor = last + 1
                    if token == ">" and content:sub( last - 1, last - 1 ) == "/" then
                        last = last - 1
                    end
                    htmltag[1] = content:sub( first, last - 1 ):gsub( "[%s]+", " " )
                
                else
                    
                    -- regular tag
                    first = content:find( "%S", last + 1 )
                    if first == nil then
                        cursor = length + 1
                        return htmltag
                    end
                    
                    while content:sub( first, first ) ~= ">" do
                        -- get tag name
                        local start, stop = content:find( "^[%a_][%w-_]*", first )
                        if start == nil then
                            cursor = first
                            return htmltag
                        end
                        
                        local name = content:sub( start, stop ):lower()
                        first, last = content:find( "^%s*=", stop + 1 )
                        if first == nil then
                            htmltag[name] = name
                        else
                            htmltag[name] = ""
                            start, stop = content:find( "%S", last + 1 )
                            if start == nil then
                                cursor = length + 1
                                return htmltag
                            end
                            
                            -- get attribute
                            local token = content:sub( start, start )
                            if token == "'" or token == '"' then
                                stop = content:find( token, start + 1, true ) or length + 1
                                htmltag[name] = content:sub( start + 1, stop - 1 )
                            elseif token == ">" then
                                stop = start-1
                            else
                                -- an unquoted HTML attribute
                                -- be as lax as reasonably possible
                                first, last = content:find( "^[^%s>]+", start )
                                if first == nil then
                                    cursor = start
                                    return htmltag
                                end
                                htmltag[name], stop = content:sub( first, last ), last
                            end
                        end
                        
                        first = content:find( "%S", stop + 1 )
                        if first == nil then
                            cursor = length + 1
                            return htmltag
                        end
                    end
                cursor = first + 1
                end
            end
        -- keep looking until we get a valid tag
        until htmltag[0] ~= nil
        return htmltag
    end
end

function Filter( content, test )
    -- return an iterator over just the tags matching the test (which can be a string
    -- or a function taking a tag table and returning true or false)
    local unfiltered = tags( content )
    if type(test) == "string" then
        return function()
            for tag in unfiltered do
                if tag[0] == test then
                    return tag
                end
            end
            return nil
        end
    elseif type(test)== "function" then
        return function()
            for tag in unfiltered do
                if test(tag) then
                    return tag
                end
            end
            return nil
        end
    end
end

function FindRefresh( content )
    function is_meta_refresh( tag )
        if tag[0] == "meta" then
            equiv = tag["http-equiv"]
            return equiv ~= nil and equiv:lower() == "refresh"
        end
    end
    for tag in Filter( content, is_meta_refresh ) do
        url = tag["content"]
        if url ~= nil then
            return url:match("[Uu][Rr][Ll]%s*=%s*(.+)")
        end
    end
    return nil
end

function FindFrame( content )
    for tag in Filter( content, "frame" ) do
        url = tag["src"]
        if url ~= nil then
            return url
        end
    end
    return nil
end

function FindJSRedirect( content )
    -- aggressively hunt for a Javascript based redirect
    local patterns = {
        'document%.location%s*=%s*(["\'])(.-)%1',
        'document%.location%.href%s*=%s*(["\'])(.-)%1',
        'document%.location%.replace%(%s*(["\'])(.-)%1%s*%)',
        'window%.location%s*=%s*(["\'])(.-)%1',
        'window%.location%.href%s*=%s*(["\'])(.-)%1',
        'window%.location%.replace%(%s*(["\'])(.-)%1%s*%)',
    }
    for i, pattern in ipairs(patterns) do
        local q, url = content:match( pattern )
        if url ~= nil then
            return url
        end
    end
    return nil
end

function FindForm( content, formIdx )
    -- returns the n-th form (a two element dictionary) or nil
    
    -- skip to first form tag, if any
    local tag = nil
    local n = formIdx
    local iter = tags( content )
    while true do
        tag = iter()
        if tag == nil then
            return nil
        end
        if tag[0] == "form" then
            -- is this the n-th form?
            n = n - 1
            if n == 0 then
                break
            end
        end
    end
    
    -- capture the inputs
    local form = nil
    form = { form=tag, inputs={} }
    tag = iter()
    while tag ~= nil and tag[0] ~= "/form" do
        if tag[0] == "input" then
            table.insert( form.inputs, tag )
        end
        tag = iter()
    end
    return form
end
