-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

require "LZObject"
require "LZXMLNode"

--
-- LZHTTPResponse
--

LZHTTPResponse = NewClass( "LZHTTPResponse", "ZAP.Network.ZHTTPResponse, ZAP.Network", LZObject )

function LZHTTPResponse.methods:GetHTTPResult()
    return self._obj:GetHTTPResult()
end

function LZHTTPResponse.methods:GetError()
    return self._obj:GetError()
end

function LZHTTPResponse.methods:GetHeader( header )
    return self._obj:GetHeader( header )
end

function LZHTTPResponse.methods:GetHeaders()
    return self._obj:GetHeaders()
end

function LZHTTPResponse.methods:RequestID()
    return self._obj:RequestID()
end

function LZHTTPResponse.methods:GetString()
    -- get underlying response string and cache it
    if self.body == nil then
        -- if we can get the content length, pass that as a hint to the underlying C++
        local buflen = self:GetContentLength() -- either -1 or a real len...
        self.body = self._obj:GetString( buflen )
    end
    return self.body
end

function LZHTTPResponse.methods:GetXML()
    -- get XML tree of response; cache results
    if self.xml == nil then
        local body = self:GetString()
        if body == nil then
            -- string was too big to cache
            native = self._obj:GetXML()
            if native ~= nil then
                self.xml = LZXMLNode( native )
            end
        else
            self.xml = LZXMLNode_ParseString( body )
        end
    end
    return self.xml
end

function LZHTTPResponse.methods:GetContentType()
    local value = self:GetHeader( "Content-Type" )
    if value == nil then
        return "unknown"
    end
    return value
end

function LZHTTPResponse.methods:GetContentLength()
    local value = self:GetHeader( "Content-Length" )
    if value == nil then
        return -1
    end
    return tonumber(value)
end

function LZHTTPResponse.methods:IsXML()
    local h = self:GetContentType()
    return (h and (string.find(h, "^text/xml") or string.find(h, "^text/x-bxml"))) ~= nil
end

function LZHTTPResponse.methods:IsHTML()
    local h = self:GetContentType()
    return (h and string.find(h, "^text/html")) ~= nil
end

function LZHTTPResponse.methods:IsResponseTo( request )
    return request and (request:RequestID() == self:RequestID())
end
