-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

-- Bootstrap the Lua execution environment.
--
-- Setup package search path and script loading to first look in the
-- .../data/state/LuaScripts directory (where updated files live), and then in
-- .../assets/ZAP.Network/LuaScripts

-- Note that these globals are set up by the C++ NZLuaState initialization:
-- ZAP_debug (bool) t/f in debug mode
-- ZAP_locale (string) current system locale (e.g. "en-US")

-- default to en-US if no locale is set
if ZAP_locale == nil or ZAP_locale == '' then
    ZAP_locale = 'en-US'
end

-- Linux defaults
local ZAP_statepath = '/disk/zap/data/state/LuaScripts/'
local ZAP_assetspath = '/disk/zap/assets/ZAP.Lua/LuaScripts/'
ZAP_platform = 'linux'
local separator = '/'

if string.find( package.path, './?', 1, true) == nil then
    -- Windows:
    ZAP_platform = 'windows'
    ZAP_statepath = '.\\data\\state\\LuaScripts\\'
    ZAP_assetspath = '.\\assets\\ZAP.Lua\\LuaScripts\\'
    separator = '\\'
end

package.path = ZAP_assetspath .. '?.lua;' .. ZAP_assetspath .. '?' .. separator .. 'init.lua'
package.path = ZAP_statepath .. '?.lua;' .. ZAP_statepath .. '?' .. separator .. 'init.lua;' .. package.path

-- load our class/object system
require "objects"

-- load our library of generic utlity functions
require "utility"

-- logging
LogMessageType  = { LOG_DEBUG = 0, LOG_RELEASE = 1, LOG_USAGE = 2 }

function zdebug( formatstr, ... )
    if formatstr ~= nil then
        _zlog( LogMessageType.LOG_DEBUG, formatstr:format( ... ) )
    end
end

function zlog( formatstr, ... )
    if formatstr ~= nil then
        _zlog( LogMessageType.LOG_RELEASE, formatstr:format( ... ) )
    end
end

-- add a Debug print method to all classes
function Object.methods:Debug( formatstr, ... )
    zdebug( self:classname() .. ':' .. formatstr, ... )
end

local function _exists(fname)
    local f = io.open(fname, "r")
    if (f and f:read()) then
        f:close()
        return true
    end
    return nil
end

-- calculate the path based on the override rules, and return the full
-- path (which can then be passed to e.g. open()) or nil if the file does
-- not exist
function ZAP_path( path )
    if ZAP_platform == 'windows' then
        path = string.gsub( path, '/', '\\' )
    end
    for i,base in ipairs({ ZAP_statepath, ZAP_assetspath }) do
        result = base .. path
        if _exists( result ) then
            return result
        end
    end
    return nil
end

-- load a script given a package name (i.e. no ".lua" extension)
-- following the default search path rules
function ZAP_loadscript( scriptname )
    require( scriptname )
end

zdebug( "Lua Initialized." )
