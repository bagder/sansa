-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    MetroFi LNetworkProvider subclass.
    MetroFi only needs an email address (no password is required).
--]]

require "LNetworkProvider"

LMetroFiProvider = newclass( "LMetroFiProvider", LNetworkProvider )

function LMetroFiProvider.methods:CredentialFields()
    return { "Email" }
end

function LMetroFiProvider.methods:TestForCompletion( request, response )
    local uri = request:GetEffectiveUri()
    return response:GetHTTPResult() == 200 and uri:find('/portal/service.htm',1,true) ~= nil
end

theNetworkProvider = LMetroFiProvider()
