-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    EspressoRoyale LNetworkProvider subclass.
    Jump to the accept URL.
--]]

require "LNetworkProvider"

EspressoRoyale = newclass( "EspressoRoyale", LNetworkProvider )

function EspressoRoyale.methods:PingRedirectLocationOverride( location )
    return 'http://192.168.168.168/iAccept.html'
end

theNetworkProvider = EspressoRoyale()
