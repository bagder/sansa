-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Generic LNetworkProvider subclass.
--]]

require "LNetworkProvider"

theNetworkProvider = LNetworkProvider()
