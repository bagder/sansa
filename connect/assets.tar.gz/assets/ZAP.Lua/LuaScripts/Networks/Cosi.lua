-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Cosi LNetworkProvider subclass.
    Jump to the accept URL after getting to login screen.
--]]

require "LNetworkProvider"

Cosi = newclass( "Cosi", LNetworkProvider )

function Cosi.methods:LoginRedirectLocationOverride( location )
    return 'http://hotspothome.com:8080/hs/key.jsp'
end

theNetworkProvider = Cosi()
