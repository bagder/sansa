-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    GoogleWiFi LNetworkProvider subclass.
    Google cookies the client, and if present, the ping will redirect to the iGoogle home page,
    with the client already logged in.
    This script isn't strictly necessary -- it just recognize success more quickly than the
    default implementation
--]]

require "LNetworkProvider"

LGoogleProvider = newclass( "LGoogleProvider", LNetworkProvider )

function LGoogleProvider.methods:TestForCompletion( request, response )
    local uri = request:GetEffectiveUri()
    return response:GetHTTPResult() == 200 and uri:find('www.google.com/ig',1,true) ~= nil
end

theNetworkProvider = LGoogleProvider()
