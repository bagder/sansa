-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    AnchorFree LNetworkProvider subclass.
    The first time a client connects to AnchorFree, it gets a splash page with a
    login form. This may or may not be required. If it't not required, the second
    request gets real internet content.
    A reconnect within a short amount of time will skip the splash page.
--]]

require "LNetworkProvider"

LAnchorFreeProvider = newclass( "LAnchorFreeProvider", LNetworkProvider )

function LAnchorFreeProvider.methods:TestForCompletion( request, response )
    local uri = request:GetEffectiveUri()
    -- first time through, assume the page is a splash page only, and re-ping (pingCount <2)
    -- >=2 times through implies the page requires a login
    return self.pingCount < 2 and response:GetHTTPResult() == 200 and uri:find('home.anchorfree.com',1,true) ~= nil
end

theNetworkProvider = LAnchorFreeProvider()
