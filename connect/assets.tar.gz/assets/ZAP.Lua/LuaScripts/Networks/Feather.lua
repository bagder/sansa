-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Feather by EarthLink (i.e. EarthLink Muni) LNetworkProvider subclass.
    non-standard WISPr
--]]

require "LNetworkProvider"

LFeatherProvider = newclass( "LFeatherProvider", LNetworkProvider )

function LFeatherProvider.methods:TestForCompletion( request, response )
    local uri = request:GetEffectiveUri()
    return response:GetHTTPResult() == 200 and uri:find('my.earthlink.net',1,true) ~= nil
end

function LFeatherProvider.methods:WISPrScriptOverride( response )
    local body = response:GetString()
    local url = body and body:match( 'window%.location%.href%s*=%s*"(.-)"')
    if url ~= nil then
        self.wisprRequest = self:SubmitGetRequest( url )
        return true
    end
    return false
end

function LFeatherProvider.methods:SupportLateWISPr()
    -- Earthlink wants to put WISPr in the body of the HTML page instead
    -- of on the body of the initial redirect
    return true
end

function LFeatherProvider.methods:CreateWISPrParams( username, password, referer )
    -- Note non-spec-compliant captitalization
    return { username=username, password=password, OriginatingServer=referer, button="Login", FNAME="0" }
end

theNetworkProvider = LFeatherProvider()
