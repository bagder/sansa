-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Pheonix Skyharbor Public wifi LNetworkProvider subclass.
    submits via javascript, gets form action from URL, and modifies one hidden field
--]]

require "LNetworkProvider"
require "url"

LPHXProvider = newclass( "LPHXProvider", LNetworkProvider )

function LNetworkProvider.methods:ComputeAction( action )
    local p = url.parse( self.loginRequest:GetEffectiveUri() )
    local q = p.query
    if q ~= nil then
        local t = ParseQuery( q )
        return t['switch_url']
    end
    return nil
end

function LPHXProvider.methods:GetOtherInputValue( name, ntype, value )
    if name == "buttonClicked" then
        return "4"
    else if name == "redirect_url" then
        return "http://sec.zing.net/default.aspx"
    end
    return value
end

theNetworkProvider = LPHXProvider()
