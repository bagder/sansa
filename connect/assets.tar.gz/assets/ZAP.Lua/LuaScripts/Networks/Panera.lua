-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Panera LNetworkProvider subclass.
    Two login forms (first is invisible). Need to post the second one.
--]]

require "LNetworkProvider"

LPaneraProvider = newclass( "LPaneraProvider", LNetworkProvider )

function LPaneraProvider.methods:ShouldHandleSecondLoginForm( loginForm )
    return loginForm.form["action"] == "/login"
end

theNetworkProvider = LPaneraProvider()
