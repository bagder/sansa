-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    WholeFoods LNetworkProvider subclass.
    Jump to the PDA login screen.
--]]

require "LNetworkProvider"

LWholeFoodsProvider = newclass( "LWholeFoodsProvider", LNetworkProvider )

function LWholeFoodsProvider.methods:PingRedirectLocationOverride( location )
    return 'http://www.deepcoolclear.com/login/wholefoods/common/welcomeWFM-PDA.htm'
end

theNetworkProvider = LWholeFoodsProvider()
