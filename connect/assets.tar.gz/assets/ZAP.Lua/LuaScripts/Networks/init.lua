-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    Table of all WiFi Networks
    Each network entry consists of:
        Key = Human Readable Network Name (e.g. "FON") -- MUST BE UNIQUE
        Value = Array of 
        1. Lua pattern to match the ESSID (e.g. "^FON_.*")
        2. Name of the icon file to use, or nil to use generic
        3. name of LNetworkProvider script file to load, or nil for Generic
    
    Please keep the list alphabetized for easy reading.
--]]

AllNetworks = {

    ["AnchorFree"] = { "^AnchorFree.*", "AnchorFree", "AnchorFree" },
    
    ["Autonet Mobile"] = { "^autonet-.*", nil, "Autonet" },
    
    ["AT&T Wi-Fi"] = { "^attwifi$", nil, nil },
    
    ["Boingo"] = { "^Boingo.*", nil, nil },
    
    ["Cosi"] = { "^Cosi$", nil, "Cosi" },
    
    ["EarthLink Wi-Fi"] = { "^FeatherByEarthLink$", nil, "Feather" },
    
    ["Espresso Royale"] = { "^EspressoRoyale$", nil, "EspressoRoyale" },
    
    ["FON"] = { "^FON_.*", "FON", nil },
    
    ["Google WiFi"] = { "^GoogleWiFi$", nil, "Google" },
    
    ["MetroFi"] = { "^MetroFi%-Free$", nil, "MetroFi" },
    
    ["Panera Bread Wi-Fi"] = { "^PANERA$", nil, "Panera" },
    
    ["Sky Harbor Public WiFi"] = { "^SKYHARBOR PUBLIC WLAN$", nil, "PHX" },
    
    ["T-Mobile HotSpot"] = { "^tmobile$", nil, nil },
    
    ["Wayport"] = { "^Wayport.*", "Wayport", nil },

    ["Whole Foods Market"] = { "^WholeFoodsMarket$", nil, "WholeFoods" },
    
}
