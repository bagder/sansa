-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    MetroFi LNetworkProvider subclass.
    MetroFi only needs an email address (no password is required).
--]]

require "LNetworkProvider"

LAutonetProvider = newclass( "LAutonetProvider", LNetworkProvider )

function LAutonetProvider.methods:CredentialFields()
    return { "PIN" }
end

theNetworkProvider = LAutonetProvider()
