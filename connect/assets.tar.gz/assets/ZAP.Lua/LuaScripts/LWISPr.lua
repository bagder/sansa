-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer, (from the C# by Arthur van Hoff)

--[[
    LWISPr parses WISPr XML and constructs appropriate responses
    WISPr is XML embedded inside an HTML document attached to a redirect.
--]]

require "LZHTTPRequest"
require "LZXMLNode"

ZWISPrMessageType = {
    Invalid             = -1,
    InitialRedirect     = 100,
    ProxyNotification   = 110,
    AuthNotification    = 120,
    LogoffNotification  = 130,
    AuthPollResponse    = 140,
    AbortLoginResponse  = 150,
}

ZWISPrResponseCode = {
    Invalid             = -1,
    NoError             = 0,
    LoginSucceeded      = 50,
    LoginFailed         = 100,
    RadiusServerError   = 102,
    RadiusNotEnabled    = 105,
    LogOffSucceeded     = 150,
    LoginAborted        = 151,
    ProxyDetection      = 200,
    AuthPending         = 201,
    GatewayError        = 255,
}

local kCommentStart = "<!--"
local kCommentEnd = "-->"
local kXml = "<?xml"
local kWISPAccessGatewayParam = "WISPAccessGatewayParam"
local kMessageType = "MessageType"
local kResponseCode = "ResponseCode"
local kLocationName = "LocationName"
local kLoginURL = "LoginURL"
local kLogoffURL = "LogoffURL"
local kNextURL = "NextURL"

LWISPrResponse = newclass( "LWISPrResponse", Object )

local function FindValidWISPr( node )
    -- some WISPr (Tully's) has extra xml nodes -- we just want the official WISPr one
    while node ~= nil do
        if node:GetName() == kWISPAccessGatewayParam then
            return node
        end
        node = node:Next()
    end
    return nil
end

local function GetNodeValue( rootnode, name )
    -- return the value of the node with the given name somewhere in the given tree
    local n = rootnode:FindNode( name )
    if n ~= nil then
        return n:GetValue()
    end
    return nil
end

function LWISPrResponse_Create( str )
    if str == nil then
        return nil
    end
    local node = nil
    while true do
        -- find the next comment:
        local i = str:find( kCommentStart, 1, true )
        local j = str:find( kCommentEnd, 1, true )
        if i == nil or j == nil then
            break
        end
        local comment = str:sub( i + #kCommentStart, j-1 ):Trim()
        -- remove comment from string:
        str = str:sub( j + #kCommentEnd )
        -- look for embedded WISPr XML in the comment:
        i = comment:find( kXml, 1, true )
        if i ~= nil then
            local wispr = comment:sub( i )
            -- EarthLink, Tully's (and others...) forget the trailing '?' in the XML-PI
            wispr = wispr:gsub( 'version="1%.0"%s*>', 'version="1.0"?>' )
            node = FindValidWISPr( LZXMLNode_ParseString( wispr ) )
            if node ~= nil then
                return LWISPrResponse( node )
            end
        end
    end
    return nil
end

function LWISPrResponse.methods:init( node )
    self.node = node
end

function LWISPrResponse.methods:GetMessageType()
    local val = tonumber( GetNodeValue( self.node, kMessageType ) )
    if val ~= nil then
        return val
    end
    return ZWISPrMessageType.Invalid
end

function LWISPrResponse.methods:GetResponseCode()
    local val = tonumber( GetNodeValue( self.node, kResponseCode ) )
    if val ~= nil then
        return val
    end
    return ZWISPrResponseCode.Invalid
end

function LWISPrResponse.methods:GetLocationName()
    return GetNodeValue( self.node, kLocationName )
end

function LWISPrResponse.methods:GetLoginURL()
    return GetNodeValue( self.node, kLoginURL )
end

function LWISPrResponse.methods:GetLogoffURL()
    return GetNodeValue( self.node, kLogoffURL )
end

function LWISPrResponse.methods:GetNextURL()
    return GetNodeValue( self.node, kNextURL )
end

function LWISPrResponse.methods:CreateLoginRequest( params )
    local loginURL = self:GetLoginURL()
    if loginURL == nil then
        return nil
    end
    
    local post = UrlEncode( params )

    local i = loginURL:find( '?', 1, true )
    if i ~= nil then
        post = loginURL:sub( i+1 ) .. "&" .. post
        loginURL = loginURL:sub( 1, i-1 );
    end
    return loginURL, post
end
