-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer, (from the C# by Arthur van Hoff)

--[[
    LNetworkProvider class encapsulates logging in to WiFi Network Providers who
    use captive portal based authentication. The default implementation does its
    best to handle WISPr, follow redirects, submit login forms, etc. Subclasses
    may specialize this behavior for specific networks.
--]]

require "LZHTTPRequest"
require "LZRegistry"
require "LWISPr"
require "LLog"
require "url"
require "html"

local sFormUrlEncode = "application/x-www-form-urlencoded"
local sSuccess = "success"
local kLocationHeader = "Location"
local kWISPAccessGatewayParam = "WISPAccessGatewayParam"

-- lets us do: if IsRedirect[httpResult] then ...
local IsRedirect = { [301]=true, [302]=true, [303]=true, [305]=true, [307]=true } 

-- maximum number of times to retry the pings. Too many and failures can take forever, too few
-- and we might miss a success. In practice 3 to 4 seems about right
local kMaxPings = 4

local ZWiFiSetupStatus = { Unknown=0, Requesting=1, Looking=2, Connecting=3,
                            Authorizing=4, Checking=5, Listing=6, Connected=7,
                            Failed=8, FlightMode=9, BadPassword=10, AuthNeeded=11,
                            AuthFailed=12, Cancelled=13, Done=14 }

LNetworkProvider = newclass( "LNetworkProvider", Object )

function LNetworkProvider.methods:init()
    self.credentials = {}
    self.pingCount = 0
    self.policy = nil
    self.script = nil
    self.name = nil
    self.stringtable = self:LoadStringTable()
    self.log = LLog()
    local registry = LZRegistry_Instance()
    self.pinghost = registry:ReturnStringField( 'wifi.ping.host' ) or 'ping.zing.net'
end

function LNetworkProvider.methods:GetPingURL( secure )
    return string.format( "http%s://%s/", (secure and 's' or ''), self.pinghost )
end

function LNetworkProvider.methods:SetCredentials( credentials )
    if credentials == nil then
        credentials = {}
    end
    self.credentials = credentials
end

function LNetworkProvider.methods:LoadStringTable()
    local st = {}
    local zstpath = ZAP_path( 'Networks/prompts_' .. ZAP_locale .. '.zst' )
    if zstpath == nil and ZAP_locale ~= "en-US" then
        -- no localized prompts -- fall back to enlish
        zstpath = ZAP_path( 'Networks/prompts_en-US.zst' )
    end
    if zstpath == nil then
        self:Debug("no prompts string table!")
        return st
    end
    local node = LZXMLNode_ParseFile( zstpath )
    node = node:Child()
    while node ~= nil do
        st[node:GetAttributeValue("name")] = node:GetValue()
        node = node:Next()
    end
    return st
end

function LNetworkProvider.methods:GetCredentialPrompt( key )
    local val = self.stringtable[ string.format("%s_%s", self.script, key) ]
    if self.script ~= "Generic" and val == nil then
        -- custom script, but no custom prompt. fall back to default
        val = self.stringtable[ string.format("Generic_%s", key) ]
    end
    if val ~= nil then
        -- give the prompt a chance to include the network name
        val = string.format( val, self.name )
    end
    return val
end

function LNetworkProvider.methods:CredentialFields()
    -- may be overriden by subclasses; a leading "*" indicates a password (obscured) field
    return { "Username", "*Password" }
end

function LNetworkProvider.methods:GetCredentialFields()
    -- return the credential fields, but with any *'s removed
    local fields = {}
    for i,k in ipairs(self:CredentialFields()) do
        local key = k
        if k:sub(1,1) == "*" then
            key = k:sub(2)
        end
        table.insert( fields, key )
    end
    return fields
end

function LNetworkProvider.methods:GetUsernameCredential()
    -- returns the first non-password credential value
    for i,k in ipairs(self:CredentialFields()) do
        if k:sub(1,1) ~= "*" then
            return self.credentials[k]
        end
    end
    return nil
end

function LNetworkProvider.methods:GetPasswordCredential()
    -- returns the first password-like credential
    for i,k in ipairs(self:CredentialFields()) do
        if k:sub(1,1) == "*" then
            return self.credentials[k:sub(2)]
        end
    end
    return nil
end

function LNetworkProvider.methods:GetCredentialInputs()
    -- inputs is a table of key:prompt pairs. the user will be presented
    -- with each prompt in turn, and the key:value pairs (where each value comes
    -- from the user) are then stored in the AP's credentials hashtable
    -- The special key 'fields' provides an ordering to the items; if an item
    -- in the fields list starts with a '*', then it is marked as obscured for
    -- the UI. (the '*' is not part of the key).
    
    local inputs = { ['fields'] = table.concat(self:CredentialFields(),",") }
    for i,key in ipairs(self:GetCredentialFields()) do
        inputs[key] = self:GetCredentialPrompt(key)
    end
    return inputs
end

function LNetworkProvider.methods:GetPolicy()
    return self.policy
end

function LNetworkProvider.methods:CheckNetwork()
    self.pingCount = 0
    self:PingNetwork()
end

function LNetworkProvider.methods:PingNetwork()
    self.pingCount = self.pingCount + 1
    self.log:Append("PING %d", self.pingCount)

    -- ping port 80
    self.ping80Succeeded = false
    self.ping80Request = self:SubmitGetRequest( self:GetPingURL(), true )

    -- port 443 will get pinged if port 80 succeeds
    self.ping443Succeeded = false
    self.ping443Request = nil
end

function LNetworkProvider.methods:CancelPing()
    self.ping80Request = nil
    self.ping80Succeeded = false
    self.ping443Request = nil
    self.ping443Succeeded = false
end

function LNetworkProvider.methods:Done( saveLog )
    -- clean up any allocated resources
    self:CancelPing()
    self.credentials = nil
    self.wisprRequest = nil
    self.loginRequest = nil
    self.authRequest = nil
    self.authFormInfo = nil
    if saveLog or ZAP_debug then
        self.log:Dump()
    end
    self.log:Clear()
    collectgarbage()
end

function LNetworkProvider.methods:SubmitGetRequest( url, nocache )
    local request = LZHTTPRequest_Create( "GET", url )
    if nocache then
        request:SetHeader( "Cache-Control", "no-cache" )
    end
    self.log:Append( request, "GET", url )
    return self:SubmitRequest( request )
end

function LNetworkProvider.methods:SubmitPostRequest( url, data )
    local request = LZHTTPRequest_Create( "POST", url )
    request:SetPostString( data, sFormUrlEncode )
    self.log:Append( request, "POST", url, data )
    return self:SubmitRequest( request )
end
        
function LNetworkProvider.methods:SubmitRequest( request )
    request:IgnoreNetworkCheck( true )
    request:CacheSession( false )
    request:SetFollowRedirects( false )
    request:SetDNSTimeout( 25 )
    request:WaitUntilComplete( true )
    request:SendAsync()
    return request
end

function LNetworkProvider.methods:HasReasonableBody( response )
    -- return true if the response is reasonably some sort of text or html
    local h = response:GetContentType():lower()
    return h == "unknown" or h:StartsWith("text") or h:StartsWith("html")
end

function LNetworkProvider.methods:SniffWISPr( response )
    local body = response:GetString()
    -- look for a WISPr message, and if found return an LWISPrResponse object
    if body ~= nil and body:find( kWISPAccessGatewayParam ) ~= nil then
        wispr = LWISPrResponse_Create( body )
        if wispr == nil then
            self.log:Append( "WISPr sniffed but not parsed %s", body )
        else
            self.log:Append( "WISPr sniffed MessageType=%d", wispr:GetMessageType() )
            return wispr
        end
    end
    return nil
end


function LNetworkProvider.methods:CreateWISPrParams( username, password, referer )
    -- return the default WISPr login POST params.
    return { UserName=username, Password=password, OriginatingServer=referer, button="Login", FNAME="0" }
end

function LNetworkProvider.methods:HandleWISPrRequest( wispr )
    local wisprMessageType = wispr:GetMessageType()
    self.log:Append("WISPr detected: %d, %d", wisprMessageType, wispr:GetResponseCode() )
    if wisprMessageType == ZWISPrMessageType.InitialRedirect then
        -- pick user or provider credentials
        if self:HaveCredentials() == false then
            self.log:Append("WISPr auth needed")
            return true, ZWiFiSetupStatus.AuthNeeded
        end
        local username = self:GetUsernameCredential()
        local password = self:GetPasswordCredential()
        local params = self:CreateWISPrParams( username, password, self:GetPingURL() )
        local wisprPostUrl, wisprPostData = wispr:CreateLoginRequest( params )
        if wisprPostUrl == nil then
            self.wisprRequest = nil
        else
            self.wisprRequest = self:SubmitPostRequest( wisprPostUrl, wisprPostData )
            return true, ZWiFiSetupStatus.Authorizing
        end
    elseif wisprMessageType == ZWISPrMessageType.ProxyNotification and wispr:GetResponseCode() == ZWISPrResponseCode.ProxyDetection then
        local nextUrl = wispr:GetNextURL() or self:GetPingURL()
        self.log:Append("WISPr proxy %s", nextUrl)
        self.ping80Request = self:SubmitGetRequest( nextUrl )
        return true, nil
    else
        self.log:Append("unexpected WISPr message: %d", wisprMessageType )
    end
    return false, nil
end

function LNetworkProvider.methods:PingRedirectLocationOverride( location )
    -- allow script to change (or set) location of initial redirect
    return location
end

function LNetworkProvider.methods:HandlePingResponse( response )
    self.log:Append("Ping response")
    
    local httpResult = response:GetHTTPResult()
    
    if IsRedirect[httpResult] then
        local location = response:GetHeader( kLocationHeader )
        self:CancelPing()
        
        -- check for WISPr
        local wispr = self:SniffWISPr( response )
        if wispr ~= nil then
            local handled, newstate = self:HandleWISPrRequest( wispr )
            if handled then
                return handled, newstate
            end
        end
        
        -- redirect
        location = self:PingRedirectLocationOverride( location )
        if location ~= nil then
            self.loginRequest = self:SubmitGetRequest( location )
            return true, nil
        end
    
    elseif httpResult == 200 then
        
        local body = response:GetString()
        -- look for the success body. We have a looser definition of success (startswith)
        -- since some transparent proxies insist on screwing with the body (MetroFi)
        if body ~= nil and body:StartsWith(sSuccess) then
            if response:IsResponseTo( self.ping80Request ) then
                self.log:Append("Ping OK %s", self:GetPingURL())
                self.ping80Succeeded = true
                -- port 80 is OK, now try 443:
                self.ping443Request = self:SubmitGetRequest( self:GetPingURL(true), true )
            elseif response:IsResponseTo( self.ping443Request ) then
                self.log:Append("Ping OK %s", self:GetPingURL(true) )
                self.ping443Succeeded = true
            end
            if self.ping80Succeeded and self.ping443Succeeded then
                -- all pings ok
                self.log:Append("SUCCESS: Pings Complete")
                return true, ZWiFiSetupStatus.Connected
            end
            return true, nil
        
        else
            -- look for WISP in a 200 body, as it could have a meta-equiv refresh
            local wispr = self:SniffWISPr( response )
            if wispr ~= nil then
                local handled, newstate = self:HandleWISPrRequest( wispr )
                if handled then
                    return handled, newstate
                end
            end
            
            -- check for meta-refresh
            local location = body and html.FindRefresh( body )
            location = self:PingRedirectLocationOverride( location )
            if location ~= nil then
                self.loginRequest = self:SubmitGetRequest( location )
                return true, nil
            end
            
        end
        
    end
    
    -- unknown status after trying one ping -- try again
    if self.pingCount == 1 then
        self.log:Append("first retry ping")
        self:CancelPing()
        self:PingNetwork()
        return true, nil
    -- unknown status after two pings -- get a bit more aggressive -- perhaps there's a JavaScript redirect
    elseif self.pingCount == 2 then
        local body = response:GetString()
        local location = body and html.FindJSRedirect( body )
        if location ~= nil then
            self.log:Append("JS redirect")
            self.loginRequest = self:SubmitGetRequest( location )
            return true, nil
        end
    end
    
    self.log:Append("FAILURE: ping")
    -- really ZWiFiSetupStatus.Failed -- upper level will translate. We
    -- send Done to signal a failure of the initial ping w/o ever seeing a portal
    return true, ZWiFiSetupStatus.Done
end

function LNetworkProvider.methods:WISPrScriptOverride( response )
    return false
end

function LNetworkProvider.methods:HandleWISPrResponse( response )
    self.log:Append("WISPr request")
        
    local httpResult = response:GetHTTPResult()
    
    if httpResult == 200 or IsRedirect[httpResult] then
        local wisprResponse = self:SniffWISPr( response )
        if wisprResponse ~= nil then
            responseCode = wisprResponse:GetResponseCode()
            self.log:Append("WISPr response to login: %d, %d", wisprResponse:GetMessageType(), responseCode)
            if responseCode == ZWISPrResponseCode.LoginSucceeded then
                self.log:Append("WISPr login OK")
                self:PingNetwork()
                return true, nil
            else
                self.log:Append("FAILURE: WISPr login")
                return true, ZWiFiSetupStatus.AuthFailed
            end
        end
    end
    
    if IsRedirect[httpResult] then
        local location = response:GetHeader( kLocationHeader )
        if location ~= nil then
            location = url.absolute( self.wisprRequest:GetEffectiveUri(), location )
            self.wisprRequest = self:SubmitGetRequest( location )
            return true, nil
        end
    end
    
    if self:TestForCompletion( self.wisprRequest, response ) and self.pingCount < kMaxPings then
        self.log:Append("probably WISPr splash page")
        self:PingNetwork()
        return true, nil
    end
    
    if self:WISPrScriptOverride( response ) then
        return true, nil
    end
    
    self.log:Append("FAILURE: WISPr login unknown")
    return true, ZWiFiSetupStatus.Failed
end

function LNetworkProvider.methods:SupportLateWISPr()
    -- look for WISPr in a 200 body? Earthlink and the Cloud
    -- seemd to want to put WISPr in the body of the HTML page instead
    -- of on the body of the initial redirect
    return nil
end

function LNetworkProvider.methods:LoginFormIndex()
    -- give scripts a chance to specify which login form on a page is the right one
    return 1
end

function LNetworkProvider.methods:LoginRedirectLocationOverride( location )
    -- allow script to change (or set) location of login redirect
    return location
end

function LNetworkProvider.methods:HandleLoginResponse( response )
    self.log:Append("Login response")
    
    self.loginRequest:Close()
    
    local httpResult = response:GetHTTPResult()
    
    if IsRedirect[httpResult] then
        local location = response:GetHeader( kLocationHeader )
        location = self:LoginRedirectLocationOverride( location )
        if location ~= nil then
            location = url.absolute( self.loginRequest:GetEffectiveUri(), location )
            self.loginRequest = self:SubmitGetRequest( location )
            return true, nil
        end
    
    elseif httpResult == 200 then
        
        if self:HasReasonableBody( response ) then
            -- parse login form
            local doc = response:GetString()
            if doc == nil then
                -- failed to parse response
                self.log:Append("FAILURE: login empty body")
                return true, ZWiFiSetupStatus.Failed
            end
            
            local wispr = self:SupportLateWISPr() and self:SniffWISPr( response )
            if wispr ~= nil then
                local handled, newstate = self:HandleWISPrRequest( wispr )
                if handled then
                    return handled, newstate
                end
            end
            
            -- check for refresh
            local location = html.FindRefresh( doc )
            location = self:LoginRedirectLocationOverride( location )
            if location ~= nil then
                location = url.absolute( self.loginRequest:GetEffectiveUri(), location )
                self.loginRequest = self:SubmitGetRequest( location )
                return true, nil
            end
            
            -- some portals just return a splash page but that's it. they just need a bit of nudging
            if self:TestForCompletion( self.loginRequest, response ) and self.pingCount < kMaxPings then
                self.log:Append("probable splash page. Re-ping")
                self:PingNetwork()
                return true, nil
            end
            
            -- parse and possibly submit login form
            local loginForm = html.FindForm( doc, self:LoginFormIndex() )
            if loginForm ~= nil then
                local handled, newstatus = self:HandleLoginForm( loginForm )
                if handled then
                    return handled, newstatus
                end
            else
                self.log:Append("No login form")
            end
            
            -- no login form after two pings
            -- perhaps there's a frameset in the form?
            if self.pingCount == 2 then
                location = doc and html.FindFrame( doc )
                if location ~= nil then
                    self.log:Append("frameset guess redirect")
                    self.loginRequest = self:SubmitGetRequest( location )
                    return true, nil
                end
            end
  
            if self.pingCount < kMaxPings then
                self.log:Append("login re-ping")
                self:PingNetwork()
                return true, nil
            end
        end
    end -- 200
    self.log:Append("FAILURE: bad login")
    return true, ZWiFiSetupStatus.Failed
end

function LNetworkProvider.methods:ComputeAction( action )
    return action
end

function LNetworkProvider.methods:HandleLoginForm( loginForm )
    -- determine if form is a login form, and post our credentials to it
    -- if possible
    
    if self:FormNeedsCredentials( loginForm ) and self:HaveCredentials() == false then
        -- Form needs credentials, and we don't have them -- ask the user
        self.log:Append("Form found; need credentials")
        return true, ZWiFiSetupStatus.AuthNeeded
    end
    
    -- get the form action, and give scripts a chance at it
    local action = loginForm.form["action"]
    action = self:ComputeAction( action )
    
    if action ~= nil then
        local location = url.absolute( self.loginRequest:GetEffectiveUri(), action )
        self.log:Append("Form action: %s", location)
        -- remember a bit of information about the form to see if we get it again:
        self.authFormInfo = { action, #(loginForm.inputs) }
        -- post the form
        self.authRequest = self:SubmitPostRequest( location, self:GetPostString( loginForm ) )
        return true, ZWiFiSetupStatus.Authorizing
    end
    
    -- not handled
    return false, nil
end

function LNetworkProvider.methods:SameLoginForm( loginForm )
    -- return true if we've seen this login form before
    if loginForm ~= nil then
        -- check to see if the form looks like the login form we already saw:
        if self.authFormInfo ~= nil then
            if self.authFormInfo[1] == loginForm.form["action"] and self.authFormInfo[2] == #loginForm.inputs then
                -- it's the same form:
                return true
            end
            -- not the same form
            return false
        end
    end
    -- no login form
    return false
end

function LNetworkProvider.methods:HandleAuthResponse( response )
    self.log:Append("Auth response")
    
    self.authRequest:Close()
    local httpResult = response:GetHTTPResult()
    
    -- first chance to test for success -- before all the redirects..
    if self:TestForCompletion( self.authRequest, response ) and self.pingCount < kMaxPings then
        self.log:Append("auth ok. Re-ping")
        self:PingNetwork()
        return true, nil
    end

    if IsRedirect[httpResult] then
        local location = response:GetHeader( kLocationHeader )
        if location ~= nil then
            location = url.absolute(self.authRequest:GetEffectiveUri(), location )
            self.authRequest = self:SubmitGetRequest( location )
            return true, nil
        end
    
    elseif httpResult == 200 then
        
        if self:HasReasonableBody( response ) then
            -- parse login form
            local doc = response:GetString()
            if doc == nil then
                -- failed to parse response
                self.log:Append("FAILURE: auth empty body")
                return true, ZWiFiSetupStatus.Failed
            end
            
            -- check for refresh
            local location = html.FindRefresh( doc )
            if location ~= nil then
                location = url.absolute(self.authRequest:GetEffectiveUri(), location )
                self.authRequest = self:SubmitGetRequest( location )
                return true, nil
            end
            
            -- second chance to test for success -- after all the redirects..
            if self:TestForCompletion( self.authRequest, response ) and self.pingCount < kMaxPings then
                self.log:Append("auth ok. Re-ping")
                self:PingNetwork()
                return true, nil
            end
            
            -- we still don't know if the auth login was good or bad
            -- now we're in guessing game land...
            
            -- if we find a form, and it looks like the login form we saw before, then we'll say we failed:
            local loginForm = html.FindForm( doc, self:LoginFormIndex() ) 
            if self:SameLoginForm( loginForm ) then
                self.log:Append("FAILURE: auth login form again")
                return true, ZWiFiSetupStatus.AuthFailed
            end
            
            -- if we have a form, but it's not the same login form, and we think we should handle it, then
            -- treat it as a login form. Subclasses can override the decision to handle this form
            if loginForm ~= nil and self:ShouldHandleSecondLoginForm( loginForm ) then
                self.log:Append("2nd login form")
                local handled, newstatus = self:HandleLoginForm( loginForm )
                if handled then
                    return handled, newstatus
                end
            end
            
            -- Otherwise we guess that we have succeeded, and try the ping again.
            if self.pingCount < kMaxPings then
                self.log:Append("auth possibly ok. Re-ping")
                self:PingNetwork()
                return true, nil
            end
            
            -- Fail -- to many ping failures
            self.log:Append("FAILURE: auth too many pings")
            return true, ZWiFiSetupStatus.Failed
        end
    end
    
    self.log:Append("FAILURE: auth response unknown")
    return true, ZWiFiSetupStatus.Failed
end

function LNetworkProvider.methods:TestForCompletion( request, response )
    return false
end

function LNetworkProvider.methods:ShouldHandleSecondLoginForm( loginForm )
    -- should we handle a second form found on the auth response page?
    -- often the page could be a portal page with a search box, so by default we
    -- only handle forms with text and password inputs
    return self:FormNeedsCredentials( loginForm, true )
end

function LNetworkProvider.methods:HandleResponse( response )
    -- called with the LZHTTPResponse object (which should not be nil)
    -- returns a handled (true or false), and a new WifiSetupStatus state,
    --     or nil to stay in the current state.
    
    self.log:Append( response )
    
    if response:IsResponseTo( self.ping80Request ) or response:IsResponseTo( self.ping443Request ) then
        return self:HandlePingResponse( response )
    end
    
    if response:IsResponseTo( self.wisprRequest ) then
        return self:HandleWISPrResponse( response )
    end
    
    if response:IsResponseTo( self.loginRequest ) then
        return self:HandleLoginResponse( response )
    end
    
    if response:IsResponseTo( self.authRequest ) then
        return self:HandleAuthResponse( response )
    end
    
    -- unhandled
    self:Debug("response to unknown request -- not handling")
    return false, nil
end

function LNetworkProvider.methods:FormNeedsCredentials( form, exact )
    -- return true if the given form looks like a login form
    -- (i.e. has a text or password input element). If exact is true, then form MUST have both elements
    local seenText = false
    local seenPassword = false
    for i,input in ipairs(form.inputs) do
        local ntype = input["type"]
        if ntype:CaselessCompareTo("text") then
            seenText = true
        elseif ntype:CaselessCompareTo("password") then
            seenPassword = true
        end
    end
    if exact then
        return seenText and seenPassword
    else
        return seenText or seenPassword
    end
end

function LNetworkProvider.methods:HaveCredentials()
    -- return true if we have credentials for this provider
    for i,k in ipairs(self:GetCredentialFields()) do
        if self.credentials[k] == nil or self.credentials[k] == '' then
            return false
        end
    end
    return true
end

function LNetworkProvider.methods:GetOtherInputValue( name, ntype, value )
    return value
end

function LNetworkProvider.methods:GetPostString( form )
    local t = {}
    for i,input in ipairs(form.inputs) do
        local name, value = input["name"], input["value"]
        local ntype = input["type"] or ''
        if ntype:CaselessCompareTo("image") then
            -- image maps might not have a name
            if name == nil then
                t["x"] = self:GetOtherInputValue( "x", ntype, '1' )
                t["y"] = self:GetOtherInputValue( "y", ntype, '1' )
            else
                local nkey = name .. ".x"
                t[nkey] = self:GetOtherInputValue( nkey, ntype, '1' )
                nkey = name .. ".y"
                t[nkey] = self:GetOtherInputValue( nkey, ntype, '1' )
                if value ~= nil then
                    t[name] = self:GetOtherInputValue( name, ntype, value )
                end
            end
        elseif name ~= nil then
            if ntype:CaselessCompareTo("text") then
                t[name] = self:GetUsernameCredential() or ''
            elseif ntype:CaselessCompareTo("password") then
                t[name] = self:GetPasswordCredential() or ''
            elseif ntype:CaselessCompareTo("radio") then
                -- use the checked item, or the first one if none are checked
                value = self:GetOtherInputValue( name, ntype, value )
                if t[name] == nil or input["checked"] ~= nil then
                    t[name] = value
                end
            else
                -- some other input (hidden field, checkbox). Get the value,
                -- and give subclasses a chance to change it if needed.
                t[name] = self:GetOtherInputValue( name, ntype, value ) or ''
            end
        end
    end
    return UrlEncode( t )
end
