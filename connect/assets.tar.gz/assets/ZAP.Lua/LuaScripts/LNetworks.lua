-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer, (from the C# by Arthur van Hoff)

--[[
    Manage the list of Networks; Load and activate a specific LNetworkProvider
--]]

-- load the big table of all known networks
require "Networks"
require "Policy"

-- the active LNetworkProvider -- set by LNetworkProvide_Choose()
theNetworkProvider = nil

function NetworkSelect( essid )
    -- load the approriate network provider code based on the essid

    -- reset the global
    theNetworkProvider = nil

    local name, icon, policy, script = NetworkMatch( essid )
    
    local f,e = loadfile( ZAP_path( 'Networks/' .. script .. '.lua' ) )
    if f == nil then
        zdebug( 'Error loading script ' .. script .. ' error: ' .. tostring(e) )
    else
        f()
        theNetworkProvider.policy = policy
        theNetworkProvider.script = script
        local netname = "(none)"
        theNetworkProvider.name = essid
        if name ~= nil then
            netname = name
            theNetworkProvider.name = name
        end
        local ssid = tostring(essid):UrlEncode()
        theNetworkProvider.log:Append( LogMessageType.LOG_USAGE, "ESSID %q Network %q Script %q", ssid, netname, script )
    end
end

function NetworkMatch( essid )
    -- scan known network provider list
    -- and if found, return human network name, access policy, icon path, and custom script name (if any)
    
    local name, script, icon = nil, nil, nil
    
    if essid ~= nil then
        for n, t in pairs(AllNetworks) do
            local p,i,s = t[1],t[2],t[3]
            if essid:find(p) then
                name, icon, script = n, i, s
                break
            end
        end
    end
    
    -- default
    script = script or "Generic"
    
    return name, icon, NetworkPolicyLookup( name ), script
end

function NetworkIconPath( name )
    -- given a network name, return the path to the icon file
    -- or a suitable default
    local entry = AllNetworks[name]
    if entry ~= nil then
        return entry[2]
    end
    return nil
end
