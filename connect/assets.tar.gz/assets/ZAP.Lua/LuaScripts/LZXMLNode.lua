-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

require "LZObject"

--
-- LZXMLNode
--

LZXMLNode = NewClass( "LZXMLNode", "ZAP.Core.ZXMLNode, ZAP.Core", LZObject )

function LZXMLNode_ParseString( str )
    rootnode = NZXMLNode.ParseString( str )
    if rootnode ~= nil then
        return LZXMLNode( rootnode )
    end
    return nil
end

function LZXMLNode_ParseFile( path )
    -- convenience wrapper -- parse an XML file
    local f = io.open( path, "r" )
    if f ~= nil then
        local xmlstr = f:read( "*all" )
        f:close()
        return LZXMLNode_ParseString( xmlstr )
    end
    return nil
end

function LZXMLNode.methods:init( obj )
    LZObject.methods.init( self, obj )
    self.attributes = self._obj:InflateAttributes()
end

function LZXMLNode.methods:GetValue()
    return self._obj:GetValue()
end

function LZXMLNode.methods:GetName()
    return self._obj:GetName()
end

function LZXMLNode.methods:GetAttributeValue( attrname )
    return self.attributes[attrname]
end

function LZXMLNode.methods:GetCaselessAttributeValue( attrname )
    -- test the node to see if it has an attribute of the given name without regard to case.
    -- if so, return its value, and the true attr name. If not, just return nil.
    for k in pairs(self.attributes) do
        if k:lower() == attrname:lower() then
            return self.attributes[k], k
        end
    end
    return nil
end

function LZXMLNode.methods:Next()
    if not self.next then
        native = self._obj:Next()
        self.next = native and LZXMLNode(native)
    end
    return self.next
end

function LZXMLNode.methods:Child()
    if not self.child then
        native = self._obj:Child()
        self.child = native and LZXMLNode(native)
    end
    return self.child
end

function LZXMLNode.methods:Walk( fn )
    fn( self )
    local c = self:Child()
    if c then
        c:Walk( fn )
    end
    local n = self:Next()
    if n then
        n:Walk( fn )
    end
end

function LZXMLNode.methods:Dump()
    local attrs = ""
    for k,v in pairs(self.attributes) do
        attrs = attrs .. ' ' ..  k .. '="' .. tostring(v) .. '"'
    end
    local n = self:GetName()
    local v = self:GetValue()
    local s = "<" .. n .. attrs .. ">"
    if v then
        s = s .. v .. "</" .. n .. ">"
    end
    zdebug( "%s", s )
end

function LZXMLNode.methods:HasName( name )
    -- compare the given name to the nodes name in a caseless
    local myname = self:GetName()
    if myname ~= nil then
        return myname:CaselessCompareTo( name )
    end
    return false
end

function LZXMLNode.methods:Find( testfn )
    -- find a node in the tree from self where testfn(self) returns true
    if testfn( self ) then
        return self
    end
    local node = self:Child()
    while node ~= nil do
        local found = node:Find( testfn )
        if found ~= nil then
            return found
        end
        node = node:Next()
    end
    return nil
end

function LZXMLNode.methods:FindNode( name )
    -- find a node with the given name:
    return self:Find( function(node) return node:GetName() == name; end )
end

function LZXMLNode.methods:FindNodeCaseless( name )
    -- find a node with the given name, using caseless comparison:
    return self:Find( function(node) return node:HasName(name); end )
end
