-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer, (from the C# by Arthur van Hoff)

--[[
    Policy.Lua
    
    Master file of all access policies on all devices
--]]

require "LZRegistry"


--[[
    List of access policy types. In practice, there is no practical difference
    between "Free" and "Generic", however when the policy provides the
    credentials (e.g. free access w/no login required) we use Free, as the UI may
    want to do something different.
--]]

local AccessPolicy = {
    
    -- for whatever reason, the user should not be allowed to use this network
    Denied = -1,
    
    -- open access, no restrictions. credentials either not needed or must be user provided
    Generic = 0,
    
    -- Wifi Network provides free access via some mechanism (perhaps credentials specified below)
    Free = 1,
    
    -- Access provided for free until a certain amount of time has passed (e.g. 30 days free)
    TimeLimited = 2,
    
    -- Access provided for free until a certain date
    DateLimited = 3,
    
    -- Access provided but must watch an ad before starting
    AdsBefore = 4,
    
    -- Access provided but ad supported 
    AdsDuring = 5,
}

function NetworkPolicyLookup( network )
    -- determine the network access policy from the given network name
    -- If theNetworkProvider is set, this scripts may update the credentials, etc. as needed
    -- to implement the policy.
    
    -- If network is nil, then there was no network matched with the scanned ESSID.
    if network == nil then
        return AccessPolicy.Generic
    end

    local registry = LZRegistry_Instance()
    local productName = registry:ReturnStringField( 'ZING.ProductName' )
    local productPartner = registry:ReturnStringField( 'ZING.Product.Partner' )
    
    if productPartner == "SanDisk" then
        -- SanDisk only deals
        
        if productName == "Sansa Connect" then
            -- SanDisk Sansa Connect only deals
            
            -- Example:
            -- if network == "ATT" then
            --    if theNetworkProvider ~= nil then
            --        theNetworkProvider:SetCredentials( "foo", "bar" )
            --    end
            --    return AccessPolicy.Free
            -- end
        
        end
    
    end
    
    if productPartner == "Sirius" then
        -- Sirius only deals
        -- ...        
    end
    
    -- ZING generic deals go here...
    
    -- default 
    return AccessPolicy.Generic
end
    