-- Single Inheritance, always virtual class system
-- Adapted from example at http://lua-users.org/wiki/ClassesAndMethodsExample

Object = {
    super = nil,
    name = "Object",
    new = function(class)
              local obj  = {class = class}
              local meta = {
                  __index = function(self,key) return class.methods[key] end,
                  __tostring = function(self) return "object " .. class.name; end,
              }
              setmetatable(obj,meta)
              return obj
          end,
    methods = {
        classname = function(self) return(self.class.name) end,
        init=function(self) end,
        },
    data = {}
}

setmetatable(Object, {
    __tostring = function(self) return "class " .. self.name end,
})

function newclass(name, super)
    if super == nil then
        super = Object
    end

    local class = {
        super = super,
        name = name,
        new = function(self, ...)
                  local obj = super.new(self, "___CREATE_ONLY___")
                  if tostring(arg[1]) ~= "___CREATE_ONLY___" then
                      obj:init(unpack(arg))
                  end
                  return obj
              end,
        methods = {}
    }
    
    -- if class slot unavailable, check super class
    -- if applied to argument, pass it to the class method new
    setmetatable(class, {
        __index = function(self,key) return self.super[key] end,
        __call  = function(self,...) return self.new(self,unpack(arg)) end,
        __tostring = function(self) return "class " .. self.name end,
    })

    -- if instance method unavailable, check method slot in super class
    setmetatable(class.methods, {
        __index = function(self,key) return class.super.methods[key] end
    })
    
    return class
end
