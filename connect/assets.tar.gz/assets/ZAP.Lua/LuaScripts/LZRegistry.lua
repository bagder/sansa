-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

require "LZObject"

--
-- LZRegistry
--

LZRegistry = NewClass( "LZRegistry", "ZAP.Code.ZRegistry, ZAP.Code", LZObject )

function LZRegistry_Instance()
    return LZRegistry( NZRegistry.Instance() )
end

function LZRegistry.methods:ReturnStringField( key )
    return self._obj:ReturnStringField( key )
end

function LZRegistry.methods:SetStringField( key, val )
    self._obj:SetStringField( key, val )
end

function LZRegistry.methods:GetBoolean( key, defaultValue )
    val = self:ReturnStringField( key ) 
    if val == nil and defaultValue ~= nil then
        return defaultValue 
    end
    if val == 'true' or val == '1' or val:sub(1,1):upper() == 'Y' then
        return true
    end
    return false
end
