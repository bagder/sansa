-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    LLog -- a class to manage HTTP interaction logging
    The log is a table of log entries. Each entry is a table as follows:
    { "_kind" : arbitrary type string
      "_time" : "<timestamp>",
      "_msg" : "<human readable message>"
      [anything else]  : other data (optional) -- e.g. response body, headers, etc.
    }      
--]]

LLog = newclass( "LLog", Object )

local LogEntry = newclass( "LogEntry", Object )
local SystemLogEntry = newclass( "SystemLogEntry", Object )
local RequestLogEntry = newclass( "RequestLogEntry", LogEntry )
local ResponseLogEntry = newclass( "ResponseLogEntry", LogEntry )

function LogEntry.methods:init( msg )
    self.date = os.date("%Y%m%d%H%M%S")
    self.msg = msg
end

function LogEntry.methods:Dump()
    zlog( "MSG %s", self:ToString() )
end

function LogEntry.methods:ToString()
    return string.format( "%s %s", self.date, self.msg )
end

function SystemLogEntry.methods:init( obj, formatstr, ... )
    self.msg = formatstr:format( ... )
    self.bucket = obj
end

function SystemLogEntry.methods:Dump()
    _zlog( self.bucket, self.msg )
end

function RequestLogEntry.methods:init( req, meth, url, postdata )
    local message = string.format("%s [%d] %s", meth, req:RequestID(), url )
    LogEntry.methods.init( self, message )
    self.postdata = postdata
end

function RequestLogEntry.methods:Dump()
    zlog( "HTTP %s", self:ToString() )
    if self.postdata ~= nil then
        zlog( "POST DATA=%s", self.postdata )
    end
end

function ResponseLogEntry.methods:init( resp )
    local message = string.format("RESP [%d] %d (%d)", resp:RequestID(), resp:GetHTTPResult(), resp:GetError() )
    LogEntry.methods.init( self, message )
    self.headers = resp:GetHeaders()
    self.body = resp:GetString()
end

function ResponseLogEntry.methods:Dump()
    zlog( "HTTP %s", self:ToString() )
    if self.headers ~= nil then
        self:DumpHeaders()
    end
    if self.body ~= nil then
        self:DumpBody()
    end
end

function ResponseLogEntry.methods:DumpHeaders()
    zlog( "HEADERS START" )
    for i,v in ipairs(self.headers) do
        zlog( "%s", v )
    end
    zlog( "HEADERS END" )
end

function ResponseLogEntry.methods:DumpBody()
    local chunksize = 1000
    local len = #self.body
    local i=1
    zlog( "BODY START" )
    while i < len do
        zlog( "%s", self.body:sub(i,i+chunksize) )
        i = i + chunksize + 1
    end
    zlog( "BODY END" )
end

function LLog.methods:init()
    self:Clear()
end

function LLog.methods:Clear()
    self.items = {}
end

function LLog.methods:Dump()
    zlog("BEGIN")
    for i,entry in ipairs(self.items) do
        entry:Dump()
    end
    zlog("END")
end

function LLog.methods:Append( obj, ... )
    -- dispatch
    local entry = nil
    if type(obj) == "string" then
        entry = LogEntry( obj:format( ... ) )
    elseif type(obj) == "number" then
        entry = SystemLogEntry( obj, ... )
    elseif obj:classname() == "LZHTTPRequest" then
        entry = RequestLogEntry( obj, ... )
    elseif obj:classname() == "LZHTTPResponse" then
        entry = ResponseLogEntry( obj, ... )
    else
        self:Debug( "unknown type %s", type(obj) )
    end
    if entry ~= nil then
        table.insert( self.items, entry )
    end
end
