-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

require "LZObject"
require "LZHTTPResponse"

--
-- LZHTTPRequest
--

LZHTTPRequest = NewClass( "LZHTTPRequest", "ZAP.Network.ZHTTPRequest, ZAP.Network", LZObject )

function LZHTTPRequest_Create( method, uri )
    return LZHTTPRequest( NZHTTPRequest.Create( method, uri ) )
end

function LZHTTPRequest.methods:SendSync()
    return LZHTTPResponse( self._obj:SendSync() )
end

function LZHTTPRequest.methods:SendAsync()
    return self._obj:SendAsync()
end

function LZHTTPRequest.methods:RequestID()
    return self._obj:RequestID()
end

function LZHTTPRequest.methods:SetPostString( data, contentType )
    self._obj:SetPostString( data, contentType )
end

function LZHTTPRequest.methods:SetHeader( header, value )
    self._obj:SetHeader( header, value )
end

function LZHTTPRequest.methods:SetTimeout( secs )
    self._obj:SetTimeout( secs )
end

function LZHTTPRequest.methods:SetDNSTimeout( secs )
    self._obj:SetDNSTimeout( secs )
end

function LZHTTPRequest.methods:SetFollowRedirects( follow )
    self._obj:SetFollowRedirects( follow )
end

function LZHTTPRequest.methods:IgnoreNetworkCheck( ignore )
    self._obj:IgnoreNetworkCheck( ignore )
end

function LZHTTPRequest.methods:CacheSession( cache )
    self._obj:CacheSession( cache )
end

function LZHTTPRequest.methods:WaitUntilComplete( waitComplete )
    self._obj:WaitUntilComplete( waitComplete )
end

function LZHTTPRequest.methods:GetEffectiveUri()
    return self._obj:GetEffectiveUri()
end

function LZHTTPRequest.methods:Close()
    self._obj:Close()
end
