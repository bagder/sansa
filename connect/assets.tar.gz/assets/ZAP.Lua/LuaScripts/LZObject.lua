-- Copyright (c) 2007 ZING Systems Inc. Strictly Confidential. All Rights Reserved.
-- Author: David Creemer

--[[
    LZObject is the base pure Lua class for all "wrapped" NZ* C++ objects
    It maintains an "_obj" member variable that is the native (userdata)
    object. It is analagous to the ZObject C# hierarchy.
--]]


-- class mapper: maps between managed type strings and Lua classes.
-- it is used to inflate an arbitrary userdata wrapped NZObject
ClassMapper = {}

function NewClass( lua_name, managed_type, superclass )
    -- create a new class, and register it's managed type, if any
    cls = newclass( lua_name, superclass )
    if managed_type then
        ClassMapper[ managed_type ] = cls
    end
    return cls
end


LZObject = NewClass( "LZObject", "ZAP.Core.ZObject, ZAP.Core", Object )

function LZObject_Inflate( native )
    -- given an arbitrary native (userdata) object, construct the appropriate
    -- LZ* object, and reset the native object's metatable to the correct
    -- classes metatable.
    assert( native )
    tname = native:GetManagedType()
    cls = ClassMapper[tname]
    assert( cls )
    if cls ~= LZObject then
        mtname = string.gsub( cls.name, "^LZ", "NZ")
        mt = _G[ mtname ]
        native:Downcast( mt )
    end
    lua_obj = cls( native )
    return lua_obj
end

function LZObject_Call( obj, method, ... )
    fn = obj[method]
    return fn( obj, ... )
end

function LZObject.methods:init( _obj )
    -- construct an LZObject from a native object
    assert( _obj )
    self._obj = _obj
end

function LZObject.methods:GetManagedType()
    return self._obj:GetManagedType()
end
