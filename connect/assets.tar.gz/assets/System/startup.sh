#!/bin/sh

PS=/tmp/ps.$$
ps > $PS

#
# make sure mdnsd is started
#

if grep -q mdnsd $PS ; then
    echo "mdnsd already running"
elif [ -f /disk/zap/assets/System/bin/mdnsd ] ; then
    echo "starting mdnsd"
    ifup lo
    /disk/zap/assets/System/bin/mdnsd
else
    echo "mdnsd not found"
fi

# cleanup
rm -f $PS
